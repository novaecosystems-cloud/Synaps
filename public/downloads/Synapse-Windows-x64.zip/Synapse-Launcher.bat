@echo off
title Synapse AI Enterprise Desktop Launcher
echo ===================================================
echo   SYNAPSE AI - ENTERPRISE KNOWLEDGE ENGINE v1.0
echo ===================================================
echo.
echo [1/2] Connecting to Synapse Enterprise Cloud...
echo [2/2] Launching Synapse Desktop Launcher...
echo.
start https://synaps-one.vercel.app/dashboard
