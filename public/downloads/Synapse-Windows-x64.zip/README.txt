SYNAPSE AI ENTERPRISE DESKTOP & CLI SUITE
=========================================
1. Double-click Synapse-Launcher.bat to launch Synapse Desktop.
2. CLI Command: npx synapse ask "summarize contract terms"
